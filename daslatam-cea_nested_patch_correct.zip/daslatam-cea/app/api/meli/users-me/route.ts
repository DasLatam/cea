import { NextResponse } from "next/server";
import { meliFetch } from "@/lib/meli/client";
import { getMeliConnectionStatus } from "@/lib/meli/store";

export async function GET() {
  try {
    const me = await meliFetch("/users/me");
    const status = await getMeliConnectionStatus().catch(() => null);

    return NextResponse.json({
      ok: true,
      connected: true,
      data: me,
      account: status?.account
        ? {
            meli_user_id: status.account.meli_user_id,
            nickname: status.account.nickname,
            site_id: status.account.site_id,
            expires_at: status.account.access_token_expires_at ?? status.account.expires_at,
            last_error: status.account.last_error,
          }
        : null,
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        connected: false,
        error: error instanceof Error ? error.message : "No se pudo consultar /users/me",
      },
      { status: 500 },
    );
  }
}
